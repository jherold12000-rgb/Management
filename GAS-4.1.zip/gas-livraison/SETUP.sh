#!/bin/bash
echo "GAS Application - Setup"
echo "======================="
echo ""

if [ ! -d "public" ]; then
    echo "Erreur : repertoire 'public' introuvable"
    exit 1
fi

if [ ! -d "instances" ]; then
    echo "Erreur : repertoire 'instances' introuvable"
    exit 1
fi

echo "Verification de la structure..."
if [ ! -f "public/index.html" ]; then
    echo "Erreur : public/index.html introuvable"
    exit 1
fi

if [ ! -f "instances/instance-worker.js" ]; then
    echo "Erreur : instances/instance-worker.js introuvable"
    exit 1
fi

echo "✓ Structure validee"
echo ""
echo "Pour deployer :"
echo ""
echo "Instance 1 (GAS 4.0) :"
echo "  cd instances"
echo "  cp instance-worker.js ../public/worker.js"
echo "  wrangler deploy --config gas-instance.toml"
echo ""
echo "Instance 2 (GASManager) :"
echo "  wrangler deploy --config gasmanager-instance.toml"
echo ""
echo "Ou une seule instance :"
echo "  cd public && wrangler init && wrangler deploy"
