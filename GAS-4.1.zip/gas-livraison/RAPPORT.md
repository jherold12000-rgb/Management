# Rapport — GAS 4.1
Corrections apportées à partir de GAS-Final.zip. Aucune fonctionnalité ni donnée existante n'a été supprimée.

## A. Corrections effectuées

| Fichier | Problème | Correction |
|---|---|---|
| sw.js | Référençait `GAS_4_0.html` et `icons/` (dossier inexistant) | Pointé vers `index.html` et les icônes à la racine |
| manifest.json | Chemins d'icônes `icons/icon-*.png` cassés | Chemins corrigés vers la racine |
| index.html | `<link rel="shortcut icon" href="icons/favicon.ico">` cassé | Corrigé |
| index.html | 3 constantes de version incohérentes (`GPAS_VERSION='4.0'`, `APP_VERSION='3.0.0'` déclarée deux fois) | Une seule source : `const GAS_VERSION = '4.1'`. Anciennes constantes conservées comme alias pour compatibilité |
| index.html | `DB_NAME='GPAS_DB'` | Migration automatique et vérifiée vers `GAS_DB` au démarrage (`migrateGpasDbToGasDb`). `GPAS_DB` n'est jamais supprimée |
| index.html | Mot de passe haché en SHA-256 + sel fixe partagé (`GPAS_SALT_2024`) | PBKDF2 (100 000 itérations) + sel aléatoire par utilisateur. Comptes existants migrés automatiquement au premier login réussi |
| index.html | Clé admin `_ADM_B64` utilisable sans limite de tentatives | Verrouillage progressif après 5 échecs (15 min). La clé elle-même reste en local tant qu'aucun serveur de licence n'est déployé — voir limite D |
| index.html | `serverCall()` pointait en dur vers `https://VOTRE-SITE.netlify.app/.netlify/functions/...` | Redirigé vers `GASServer` (nouveau `server-adapter.js`), aucune dépendance Netlify/Cloudflare dans le code applicatif |
| instances/instance-worker.js | Implémentait seulement `/api/health` et un stockage clé-valeur générique | Implémente maintenant tout le contrat `/api/*` du §14 (établissement, terminaux, licence, sync, conflits) sur Cloudflare KV, à titre de référence |

## B. Nouvelles fonctionnalités

- `server-adapter.js` : détection automatique du serveur (apiBase configuré → API relative `/api` → mode local), aucun fournisseur en dur. Utilisable avec n'importe quel backend qui respecte le contrat `/api/*`.
- `getSyncIndicator()` : état 🟢/🟠/🔴/⚪ prêt à afficher dans l'interface.
- `diagnosticGAS()` : rapport structuré (version, IndexedDB, Service Worker, manifest, connexion, serveur, licence, terminal, synchronisation, dernière sauvegarde, opérations en attente).
- `gasError()` : point d'entrée central de journalisation d'erreurs (console + `journalActivites`).
- Règle de licence mensuelle avec tolérance jusqu'au 5 du mois suivant, codée explicitement dans `instance-worker.js` (`computeLicenceStatut`).

## C. Fonctionnalités conservées

Tous les modules existants (élèves, personnel, classes, notes, bulletins, présences, finances, documents, discipline, emplois du temps, pédagogie, licence, terminaux, sauvegarde/restauration, journal, synchronisation). Le moteur de synchronisation par file d'opérations (`operationsSync`/`conflitsSync`), déjà présent dans le fichier source, a été conservé et simplement reconnecté à un transport universel.

## D. Ce qui reste à faire

Le cahier des charges couvre 61 sections sur une application de 10 700 lignes ; cette passe a traité les priorités 1 à 3 (stabilité, compatibilité des données, sécurité de base) plus une partie de la 5 (serveur universel). Restent, par priorité :

1. **Sécurité** : la clé admin locale (`_ADM_B64`) reste en dur dans le frontend. La retirer complètement suppose un serveur de licence déployé (voir `licence-check`/`licence-activate` dans `instance-worker.js`, déjà prêts côté contrat) — sinon la fonctionnalité de déverrouillage d'urgence disparaît sans remplacement.
2. **Terminaux/CORS/HTTPS** : logique déjà présente côté client, non re-testée en conditions réelles (§19-21, §53-54).
3. **Performance** (§41) et **restructuration en modules** (§42) : non commencées, à faible risque de casser l'existant si reportées.
4. **Diagnostic/Test de santé en UI** (§39-40) : les fonctions existent (`diagnosticGAS`), pas encore branchées à un écran.
5. **Les 20 tests obligatoires du §56** demandent un appareil réel (installation PWA Android, coupure réseau, plusieurs terminaux) : non exécutables depuis cet environnement.

## E. Déploiement

Voir `DEPLOIEMENT.txt`. Rien de spécifique à Cloudflare n'est requis côté frontend : `public/` peut être servi tel quel par n'importe quel hébergeur statique. Pour activer le serveur (licence + sync), déployer `instances/instance-worker.js` avec un namespace KV (`GAS_KV`), ou implémenter le même contrat `/api/*` sur un autre backend.

## F. Migration des anciennes données

Automatique, sans action requise : au premier démarrage de cette version, `GPAS_DB` est copiée vers `GAS_DB` avec vérification du nombre d'enregistrements par store. `GPAS_DB` n'est jamais supprimée automatiquement.

## G. Procédure de test recommandée avant mise en production

1. Ouvrir l'app sur l'appareil qui contient déjà des données GPAS, vérifier dans la console que la migration s'est terminée sans erreur.
2. Couper le réseau, vérifier que toutes les fonctions locales marchent normalement.
3. Se connecter avec un compte existant : vérifier en console le message de migration du mot de passe vers PBKDF2.
4. Si un backend est déployé, vérifier `GET /api/health` puis que l'indicateur de synchronisation passe à 🟢/🟠.
