/* GAS — Gestion Administration Scolaire — Service Worker
   Mise en cache de l'app shell (architecture offline-first). Les données
   scolaires elles-mêmes restent gérées par IndexedDB dans index.html —
   ce fichier ne fait que permettre à la page de se recharger sans réseau.

   Installation : dans la page HTML,
     if('serviceWorker' in navigator && location.protocol!=='file:'){
       navigator.serviceWorker.register('./sw.js');
     }
*/
const CACHE_NAME = 'gas-shell-v4.1.0';
const APP_SHELL = [
  './',
  './index.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png',
  './apple-touch-icon.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

/* Cache d'abord pour l'app shell, avec repli réseau puis mise à jour du
   cache en arrière-plan (stale-while-revalidate simplifié). Les appels API
   serveur (licence/terminaux/sync, quel que soit l'hébergeur) passent
   toujours par le réseau normalement : ils ne font pas partie de APP_SHELL. */
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return; /* laisse passer les appels serveur externes */

  event.respondWith(
    caches.match(event.request).then((cached) => {
      const fetchPromise = fetch(event.request)
        .then((res) => {
          if (res && res.status === 200) {
            const clone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          }
          return res;
        })
        .catch(() => cached);
      return cached || fetchPromise;
    })
  );
});
