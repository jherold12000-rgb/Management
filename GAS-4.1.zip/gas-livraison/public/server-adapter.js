/* GAS — Gestion Administration Scolaire — Adaptateur serveur universel
   (§7 à §14 du cahier des charges)

   Ce module ne suppose AUCUN hébergeur particulier. Il expose un seul objet
   global, GASServer, avec des méthodes fonctionnelles (healthCheck,
   registerEtablissement, registerTerminal, heartbeat, licenceCheck,
   licenceActivate, syncPush, syncPull, resolveConflict). Le reste de
   l'application (index.html) ne doit JAMAIS appeler fetch() directement
   vers une techno spécifique (Netlify, Cloudflare Workers...) : il doit
   toujours passer par GASServer.*

   Ordre de détection (§8) :
     1. apiBase configuré explicitement (Administration → Serveur, §52)
     2. API relative sur le même domaine : /api/... (§9)
     3. Mode local/offline (§11 Mode A / §47)

   Contrat API attendu côté serveur, quel qu'il soit (§14) :
     GET  /api/health
     POST /api/register-etablissement
     POST /api/register-terminal
     POST /api/heartbeat
     POST /api/licence-check
     POST /api/licence-activate
     POST /api/sync-push
     POST /api/sync-pull
     POST /api/resolve-conflict
     GET  /api/terminaux-status

   Si le serveur détecté ne répond pas à /api/health avec un JSON valide,
   ou si une route précise manque dans "features", GAS reste pleinement
   fonctionnel en local (§13, §47, §50) : aucune fonction ne doit planter
   parce que le serveur est absent ou incomplet.
*/
(function(global){
  'use strict';

  const CFG_KEY='gas_server_config'; // { apiBase: "", mode: "auto" }
  const HEALTH_CACHE_MS=30000; // évite de re-tester le serveur à chaque appel

  let _cache={ checkedAt:0, mode:'local', apiBase:'', features:{}, ok:false };

  function _loadConfig(){
    try{ return JSON.parse(localStorage.getItem(CFG_KEY)||'null') || {apiBase:'',mode:'auto'}; }
    catch(e){ return {apiBase:'',mode:'auto'}; }
  }
  function _saveConfig(cfg){
    try{ localStorage.setItem(CFG_KEY, JSON.stringify(cfg)); }catch(e){}
  }

  async function _tryHealth(base){
    try{
      const url=(base||'')+'/api/health';
      const ctrl=new AbortController();
      const t=setTimeout(()=>ctrl.abort(),4000);
      const res=await fetch(url,{method:'GET',signal:ctrl.signal});
      clearTimeout(t);
      if(!res.ok)return null;
      const data=await res.json();
      if(!data || data.ok!==true)return null;
      return data;
    }catch(e){ return null; }
  }

  /* §8/§9 — détection automatique. Ne lève jamais d'exception : en cas
     d'échec, retourne toujours un état "local" exploitable. */
  async function detectServer(force){
    if(!force && (Date.now()-_cache.checkedAt)<HEALTH_CACHE_MS){
      return _cache;
    }
    const cfg=_loadConfig();

    // 1. apiBase configuré manuellement (§52 Administration → Serveur)
    if(cfg.apiBase){
      const data=await _tryHealth(cfg.apiBase);
      if(data){
        _cache={checkedAt:Date.now(),mode:'externe',apiBase:cfg.apiBase,features:data.features||{},ok:true};
        return _cache;
      }
    }

    // 2. API relative sur le même domaine (§9) — sauf en mode file:// où ça n'a pas de sens
    if(location.protocol!=='file:'){
      const data=await _tryHealth('');
      if(data){
        _cache={checkedAt:Date.now(),mode:'relatif',apiBase:'',features:data.features||{},ok:true};
        return _cache;
      }
    }

    // 3. Mode local (§11 Mode A / §47) — jamais une erreur, un mode normal
    _cache={checkedAt:Date.now(),mode:'local',apiBase:'',features:{},ok:false};
    return _cache;
  }

  function getStatus(){ return {..._cache}; }

  function setManualApiBase(apiBase){
    const cfg=_loadConfig();
    cfg.apiBase=apiBase||'';
    _saveConfig(cfg);
    _cache.checkedAt=0; // force un nouveau test au prochain appel
  }

  /* Message d'état lisible pour l'utilisateur (§47/§48/§50) */
  function statusMessage(st){
    st=st||_cache;
    if(st.mode==='local')return 'Mode local actif — vos données sont enregistrées sur cet appareil.';
    if(st.ok && (st.mode==='relatif'||st.mode==='externe'))return 'Serveur connecté — synchronisation activée.';
    return 'Backend non disponible — synchronisation serveur désactivée.';
  }

  async function _call(route,payload,method){
    const st=await detectServer(false);
    if(!st.ok){
      return {ok:false,local:true,message:statusMessage(st)};
    }
    try{
      const url=st.apiBase+'/api/'+route;
      const ctrl=new AbortController();
      const t=setTimeout(()=>ctrl.abort(),8000);
      const res=await fetch(url,{
        method:method||'POST',
        headers:{'Content-Type':'application/json'},
        body:method==='GET'?undefined:JSON.stringify(payload||{}),
        signal:ctrl.signal
      });
      clearTimeout(t);
      if(!res.ok)return {ok:false,local:false,error:'HTTP '+res.status};
      const data=await res.json();
      return {ok:true,local:false,data};
    }catch(e){
      // Le serveur avait répondu au health check mais échoue maintenant :
      // on dégrade proprement plutôt que de faire planter l'appelant (§13).
      return {ok:false,local:false,error:String(e&&e.message||e)};
    }
  }

  const GASServer={
    detectServer,
    getStatus,
    setManualApiBase,
    statusMessage,
    healthCheck:      ()=>detectServer(true),
    registerEtablissement: (payload)=>_call('register-etablissement',payload),
    registerTerminal:      (payload)=>_call('register-terminal',payload),
    heartbeat:             (payload)=>_call('heartbeat',payload),
    licenceCheck:          (payload)=>_call('licence-check',payload),
    licenceActivate:       (payload)=>_call('licence-activate',payload),
    syncPush:              (payload)=>_call('sync-push',payload),
    syncPull:              (payload)=>_call('sync-pull',payload),
    resolveConflict:       (payload)=>_call('resolve-conflict',payload),
    terminauxStatus:       ()=>_call('terminaux-status',null,'GET')
  };

  global.GASServer=GASServer;
})(window);
